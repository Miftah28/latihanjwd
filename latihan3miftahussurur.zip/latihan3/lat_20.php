<html>

<head>
    <title>Struktur kendali perulangan dengan FOR</title>
</head>

<body>
    <?php 
    for ($i=2; $i<=7; $i++) 
    { 
        echo "<font size=$i>Saya Belajar PHP</font><br>"; 
    }
    ?>
</body>

</html>