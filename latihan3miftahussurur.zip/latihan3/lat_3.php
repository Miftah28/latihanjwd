<html>

<head>
    <title>Menggunakan variabel</title>
</head>

<body>
    <?php 
    $jurusan = "Teknik Informatika"; 
    print ("Jurusan : $jurusan <br>"); 
    $jurusan = "Teknik Mesin"; 
    print ("Jurusan : $jurusan <br>"); 
    ?>
</body>

</html>