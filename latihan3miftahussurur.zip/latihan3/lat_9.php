<html>

<head>
    <title>Operator Aritmatika</title>
</head>

<body>
    <?php 
    $harga = 5500; 
    $banyak = 5; 
    print("Anda telah menghabiskan $banyak porsi Sate<br>\n"); 
    print("yang tiap porsi seharga Rp $harga<br>"); 
    print("Maka anda harus membayar Rp "); print($harga * $banyak); 
    ?>
</body>

</html>