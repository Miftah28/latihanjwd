<html>

<head>
    <title>Struktur kendali perulangan dengan WHILE</title>
</head>

<body>
    <?php 
    $i=1; 
    while ($i <= 10) 
    { 
        echo "Ini pengulangan yang ke $i<br>"; 
        $i++; 
        } 
        ?>
</body>

</html>