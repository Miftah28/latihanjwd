<?php 
//contoh variabel $a 
$a = "Testing"; 
//kini $a adalah variabel jenis string 
echo "Nilai a adalah <b>$a</b> (String) <br>"; 
$a = 27; 
//kini $a adalah variabel jenis integer 
echo "Nilai a berubah menjadi <b>$a</b> (Integer) <br>"; 
$a = 2.7; 
//kini $a adalah variabel jenis floating point 
echo "Nilai a sekarang menjadi <b>$a</b> (Floating point)";
?>