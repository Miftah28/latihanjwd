<?php
$i = 2; //inisialisasi
while ($i <= 100) { //Kondisi Terminasi
    echo "Bilangan bulat ke $i <br>"; //statement
$i++; //Incerment/Decerment
}
?>