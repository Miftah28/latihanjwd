<html>

<head>
    <title>Struktur kendali perulangan DO…WHILE</title>
</head>

<body>
    <?php 
    $i=1; 
    do 
    { 
        echo "Ini juga perulangan yang ke $i<br>"; 
        $i++; 
        } 
        while ($i <= 5) 
        ?>
</body>

</html>