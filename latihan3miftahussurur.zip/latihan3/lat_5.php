<html>

<head>
    <title>Menggunakan variabel</title>
</head>

<body>
    <?php 
    $jurusan = "Teknik Informatika"; 
    echo "Jurusan : $jurusan <br>"; 
    $jurusan = "Teknik Mesin"; 
    echo "Jurusan : $jurusan <br>"; 
    ?>
</body>

</html>