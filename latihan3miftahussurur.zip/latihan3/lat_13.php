<html>

<head>
    <title>Struktur kendali IF</title>
</head>

<body>
    <?php
    $sex = "m";
    if ($sex == "m") { 
        echo " Laki - Laki "; 
        }
    else
    {
        echo " Perempuan ";
    }
    ?>
</body>

</html>