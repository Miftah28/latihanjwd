<html>

<head>
    <title>Struktur kendali IF…ELSE</title>
</head>

<body> <?php $x = 9;
if ($x > 10) 
{ 
    echo "Selamat Siang"; 
    } 
    else 
    { 
        echo "Selamat Pagi"; 
        } 
        ?>
</body>

</html>