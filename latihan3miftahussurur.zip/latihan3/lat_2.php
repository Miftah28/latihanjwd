<html>

<head>
    <title>Test Penyisipan PHP pada HTML</title>
</head>

<body> Silakan sebutkan warna kesukaan anda..? <br>
    <?php 
    //Berikut ini adalah kode PHP yang disisipkan 
    echo "<b>Di Bawah ini adalah warna kesukaanku:<br>"; 
    echo "Merah, Hijau, dan Kuning </b>"; 
    ?>
</body>

</html>