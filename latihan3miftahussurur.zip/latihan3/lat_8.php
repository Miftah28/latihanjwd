<html>

<head>
    <title>Menggunakan konstanta</title>
</head>

<body>
    <?php
    define ("KAMPUS", "POLITEKNIK INDRAMAYU");
    print (KAMPUS);
    ?>
</body>

</html>