<html>

<head>
    <title>Skrip PHP Pertama</title>
</head>

<body>
    <?php echo "Ini Skrip PHP Pertamaku..!"; 
    ?>
</body>

</html>