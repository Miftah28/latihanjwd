<html>

<head>
    <title>Struktur kendali IF</title>
</head>

<body> <?php $x = 12; if ($x > 10) { echo "Selamat Siang"; } ?> </body>

</html>