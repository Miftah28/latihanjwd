<html>

<head>
    <title>Struktur kendali IF…ELSE</title>
</head>

<body>
    <?php
    $sex = "m";
    if ($sex == "m") { 
        echo " Laki - Laki "; 
        }
    elseif ($sex == "f") { 
        echo " Perempuan "; 
            }
    else
    {
        echo "Tidak Ada";
    }
    ?>
</body>

</html>